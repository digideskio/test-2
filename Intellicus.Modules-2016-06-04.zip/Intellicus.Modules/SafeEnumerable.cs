﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Intellicus.Modules
{
    public class SafeEnumerable<T> : IEnumerable<T>
    {
        private readonly IEnumerable<T> m_Inner;
        private readonly object m_Lock;

        public SafeEnumerable(IEnumerable<T> inner, object @lock)
        {
            m_Lock = @lock;
            m_Inner = inner;
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new SafeEnumerator<T>(m_Inner.GetEnumerator(), m_Lock);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
