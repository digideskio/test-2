﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Intellicus.Modules
{
    public static class EnumerableExtension
    {
       ///// <summary>
       ///// Extension method added in dot net framwork after 2.0
       ///// </summary>
       ///// <typeparam name="T">Type parameters</typeparam>
       // /// <param name="ie">Enumerable instance</param>
       ///// <param name="lock">Locking object</param>
       // /// <returns>Safe Enumerable</returns>
       // public static IEnumerable<T> AsLocked<T>(this IEnumerable<T> ie, object @lock)
       //{
       //    return new SafeEnumerable<T>(ie, @lock);
       //}
        /// <summary>
        /// Equivalent method for Extension method
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ie"></param>
        /// <param name="lock"></param>
        /// <returns></returns>
        public static IEnumerable<T> AsLocked<T>(IEnumerable<T> ie, object @lock)
        {
            return new SafeEnumerable<T>(ie, @lock);
        }
    }
}
