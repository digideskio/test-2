﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.SessionState;

namespace Intellicus.Modules
{
    public class SafeSessionStateItemCollection : ISessionStateItemCollection
    {
        private readonly SessionStateItemCollection m_Inner = new SessionStateItemCollection();
        private readonly object m_Lock = new object();

        public void Clear()
        {
            lock (m_Lock)
            {
                m_Inner.Clear();
            }
        }


        public void Remove(string name)
        {
            lock (m_Lock)
            {
                m_Inner.Remove(name);
            }
        }

        public void RemoveAt(int index)
        {
            lock (m_Lock)
            {
                m_Inner.RemoveAt(index);
            }
        }

        public object this[int index]
        {
            get
            {
                lock (m_Lock)
                {
                    return m_Inner[index];
                }
            }
            set
            {
                lock (m_Lock)
                {
                    m_Inner[index] = value;
                }
            }
        }

        public object this[string name]
        {
            get
            {
                lock (m_Lock)
                {
                    return m_Inner[name];
                }
            }
            set
            {
                lock (m_Lock)
                {
                    m_Inner[name] = value;
                }
            }
        }

        public void CopyTo(Array array, int index)
        {
            throw new NotImplementedException();
        }

        public System.Collections.IEnumerator GetEnumerator()
        {
            return new SafeEnumerator<object>((IEnumerator<object>)m_Inner.GetEnumerator(), m_Lock);
        }


        public int Count
        {
            get
            {
                lock (m_Lock)
                {
                    return m_Inner.Count;
                }
            }
        }

        public bool IsSynchronized
        {
            get { return true; }
        }

        public object SyncRoot
        {

            get { throw new NotImplementedException(); }
        }

        public bool Dirty
        {
            get
            {
                return m_Inner.Dirty;
            }
            set
            {
                m_Inner.Dirty = value;
            }
        }

        public System.Collections.Specialized.NameObjectCollectionBase.KeysCollection Keys
        {
            get
            {
                lock (m_Lock)
                {
                    // todo: do i need to sync this up
                    return m_Inner.Keys;
                }
            }
        }



    }
}
