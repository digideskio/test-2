﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Utility;
using GuideToGalaxy.Exceptions;
namespace GuideToGalaxy
{
    /// <summary>
    /// This class specifies rules for Langauge
    /// </summary>
    public class ConversionRuleList : IExpression
    {
       /// <summary>
       /// Initlization of local variables.
       /// </summary>
        public ConversionRuleList()
        {
            
        }
       
        /// <summary>
        /// Initlize rules with proper
        /// </summary>
        /// <param name="currentChar"></param>
        /// <param name="previousValue"></param>
        /// <param name="result"></param>
        public ConversionRuleList(char currentChar, int previousValue, float result)            
        {
            this._currentCharcter = currentChar;
            this._previousValue = previousValue;
            this._result = result;
        }
        /// <summary>
        /// Interpret the langauge and respond
        /// </summary>
        /// <returns></returns>
        public float Interpret()
        {
            //this.ValidateInput(this._currentCharcter);
            return this.Substract(Constants.romanCharcterValues[_currentCharcter], _previousValue, _result);
        }
        /// <summary>
        /// Holds current charcter in sequence
        /// </summary>
        private char _currentCharcter;

        /// <summary>
        /// Holds pervious charcters in sequence
        /// </summary>
        private int _previousValue;

        /// <summary>
        /// Holds sum of computations
        /// </summary>
        private float _result;

        /// <summary>
        /// Readonly property for future use
        /// </summary>
        public float Result
        {   
            get { return _result;  }            
        }

        /// <summary>
        /// Readonly property for future use
        /// </summary>
        public char CurrentCharcter
        {
            get { return _currentCharcter; }            
        }

        /// <summary>
        /// Readonly property for future use
        /// </summary>
        public int PreviousValue 
        { 
            get { return _previousValue; }            
        }
          

        /// <summary>
        /// Perform operation on Roman Numeral number drpending upon rules.
        /// </summary>
        /// <param name="current">Current charcter in sequence</param>
        /// <param name="previous">Previous charcter in sequence</param>
        /// <param name="result">Result of Roman Numeral evluation before this iteration.</param>
        /// <returns>New computed value</returns>
        private float Substract(int current, int previous, float result)
        {
            if (previous > current)
            {
                if (Constants.allowdSubstraction.Keys.Contains(current) && Constants.allowdSubstraction[current].Contains(previous))
                {
                    return result - current;
                }
                throw new RomanNumeralsException("Numerals Substratcion rules are volited");
            }
            else
            {
                return result + current;
            }
        }

    }
}
