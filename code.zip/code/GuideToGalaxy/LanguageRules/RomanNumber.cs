﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Utility;
using GuideToGalaxy.Exceptions;

namespace GuideToGalaxy
{
    /// <summary>
    /// This class interpret langauge in Roman Numerals.
    /// </summary>
    public class RomanNumber : IExpression
    {
        /// <summary>
        /// Only charcters whose value is power of ten are allowd in substraction.
        /// </summary>
        public static readonly Dictionary<int, int[]> allowdSubstraction = new Dictionary<int, int[]>() 
        {
      
            {1,new int[]{5,10}},
            {10,new int[] {50,100} },
            {100,new int [] {500,1000}}          
      
        };
        /// <summary>
        /// Roman Numeral charcters and their values.
        /// </summary>
        public static readonly Dictionary<char, int> romanCharcterValues = new Dictionary<char, int>() 
        {
      
             {'I',1},
             {'V',5},
             {'X',10},
             {'L',50},
             {'C',100},
             {'D',500},
             {'M',1000}      
     
        };

        /// <summary>
        /// Checks strings for a vlid Roman Numeral
        /// </summary>
        /// <param name="romanExpression">Roman Numeral string.</param>
        /// <returns>String is valid Roman Numeral or not</returns>
        public static bool IsValidRomanString(string romanExpression)
        {
            System.Text.RegularExpressions.Regex rgExpression = new System.Text.RegularExpressions.Regex("^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return rgExpression.Match(romanExpression).Success;
        }
        /// <summary>
        /// String which contain Roman Numeral Expression
        /// </summary>
        private string _romanExpression;
        
        /// <summary>
        ///Initialization Roman numers with Roman Numeral expression 
        /// </summary>
        /// <param name="romanExpression"></param>
        public RomanNumber(string romanExpression)
        {
            this._romanExpression = romanExpression;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
       public float Interpret()
        {
            return this.ConvertRomanToDecimal(_romanExpression);
        }

        /// <summary>
        /// Covert Roamn Expression into Decimal
        /// </summary>
        /// <param name="romanValue">Roman Expression</param>
        /// <returns>Corresponding decimal (float is not necessary.)</returns>
        private float ConvertRomanToDecimal(string romanValue)
        {
            float result = 0;
            int lastNumber = 0;
            char[] romanCharcters = romanValue.ToUpper().ToCharArray();
            IExpression conversionRules ;
            for (int i = romanCharcters.Length - 1; i >= 0; i--)
            {                
                conversionRules = new ConversionRuleList(romanCharcters[i], lastNumber,result);
                result = conversionRules.Interpret();
                lastNumber = RomanNumber.romanCharcterValues[romanCharcters[i]];
            }
            //object will available for garbage collector during mark phase
            conversionRules = null;
            return result;
        }       
    }
}
