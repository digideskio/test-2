﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuideToGalaxy.Exceptions
{
    /// <summary>
    /// This class deals with various Roman Numeral Exeception.
    /// If user wants to Log exception he can also do it here.
    /// </summary>
    public class RomanNumeralsException : Exception
    {
       public RomanNumeralsException()
            : base() { }

        public RomanNumeralsException(string message)
            : base(message) { }      

        public RomanNumeralsException(string message, Exception innerException)
            : base(message, innerException) { }
      
    }
}
