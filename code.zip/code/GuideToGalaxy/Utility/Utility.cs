﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuideToGalaxy.Utility
{
    /// <summary>
    /// This class provde common utility methods to application.
    /// </summary>
    public static class Utilities
    {
        /// <summary>
        /// Split Query string between two specific string
        /// </summary>
        /// <param name="query">Query string to be split</param>
        /// <param name="startToken">Start split string</param>
        /// <param name="endToken">End split string</param>
        /// <returns>Array of splited values.</returns>
        public static string[] SplitQueryBetweenTwoString(string query, string startToken, string endToken)
        {
            string[] queryArray = query.Split(' ');
            int startIndex = -1, endIndex = 0;
            for (int i = 0; i < queryArray.Length; i++)
            {
                if (queryArray[i].Equals(startToken, StringComparison.CurrentCultureIgnoreCase))
                {
                    startIndex = i + 1;
                }
                else if (queryArray[i].Equals(endToken, StringComparison.CurrentCultureIgnoreCase))
                {
                    endIndex = i;

                }
            }
            if (startIndex == -1) 
            {
                throw new GuideToGalaxy.Exceptions.RomanNumeralsException ("I have no idea what you are talking about"); 
            }
            string[]  splitedString = new string[queryArray.Length - startIndex - 1];
            Array.Copy(queryArray, startIndex, splitedString, 0, splitedString.Length);
            
            //object will available for garbage collector during mark phase
            //string can be huge so they can get allocated on heap.
            queryArray = null;
            return splitedString;
        }

        /// <summary>
        /// Print out put message to Console.
        /// Assumption: Rounded off values of Queries.
        /// </summary>
        /// <param name="message">Message to be print on console.</param>
        public static void PrintOutput(string message)
        {
            Console.WriteLine(message);
        }

        
      
    }
}
