﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuideToGalaxy.Utility
{
    /// <summary>
    /// This class contains various constants for application.
    /// </summary>
    class Constants
    {
        /// <summary>
        /// Allowd repatiable charcters
        /// </summary>
        public static readonly char[] reapatiableCharcters = { 'I', 'V', 'X', 'M' };

        /// <summary>
        /// Non-Repeatable charcters
        /// </summary>
        public static readonly char[] nonReapeatableChar = { 'D', 'L', 'V' };

        /// <summary>
        /// Only charcters whose value is power of ten are allowd in substraction.
        /// </summary>
        public static readonly Dictionary<int, int[]> allowdSubstraction = new Dictionary<int, int[]>() 
        {
      
            {1,new int[]{5,10}},
            {10,new int[] {50,100} },
            {100,new int [] {500,1000}}          
      
        };
        /// <summary>
        /// Roman Numeral charcters and their values.
        /// </summary>
        public static readonly Dictionary<char, int> romanCharcterValues = new Dictionary<char, int>() 
        {
      
             {'I',1},
             {'V',5},
             {'X',10},
             {'L',50},
             {'C',100},
             {'D',500},
             {'M',1000}      
     
        };
    }
}
