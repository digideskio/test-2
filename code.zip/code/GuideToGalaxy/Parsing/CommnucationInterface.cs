﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Exceptions;
using GuideToGalaxy.Utility;

namespace GuideToGalaxy
{
    /// <summary>
    /// This class answere every query by user (Merchant)
    /// </summary>
    class CommnucationInterface 
    {
        /*private IExpression _romanNumber;
        private IExpression _parseQueries;
        public AnswereQueries(IExpression romanExpression, IExpression parseQueries)
        {
            this._romanNumber = romanExpression;
            this._parseQueries = parseQueries;
        }*/

        /// <summary>
        /// Get list of quries to be answere
        /// </summary>
        private QueryParsing _queries;

        /// <summary>
        /// Default Constructor of the class
        /// </summary>
        public CommnucationInterface()
        { 

        }

        /// <summary>
        /// This Constructor is use for dependency injection.
        /// </summary>
        /// <param name="queries">Dependency object to be inject.</param>
        public CommnucationInterface(QueryParsing queries)
        {
            this._queries = queries;
        }  

        /// <summary>
        /// Itrate each question and try to find out answere.
        /// </summary>
        public void ProcessQuestions()
        {            
            foreach (string question in this._queries.QuestionsList)
            {
                GetAnswere(question);
            }
        }

        /// <summary>
        /// Classify answere depending on  
        /// </summary>
        /// <param name="question">Question to be answered</param>
        private void GetAnswere(string question)
        {
            if (question.StartsWith("how much", StringComparison.CurrentCultureIgnoreCase))
            {
                GetValueForRoman(question);
            }
            else
            {
                GetValueOfToken(question);
            }
        }

        /// <summary>
        ///Get value of Roman Numeral charcters 
        /// </summary>
        /// <param name="query">Question to be answered</param>
        private void GetValueForRoman(string query)
        {
            List<char> tokenValueToRoman = new List<char>();
            string[] tokenValue = Utilities.SplitQueryBetweenTwoString(query, "is", "?");
            for (int i = 0; i < tokenValue.Length; i++)
            {
                tokenValueToRoman.Add(this._queries.TokenMap[tokenValue[i]]);
            }

            float value = EvaluateExpression(string.Join("", tokenValueToRoman.ToArray()));
            Utilities.PrintOutput(string.Join(" ", tokenValue) + " is " + Math.Round(value));
           
            //object will available for garbage collector during mark phase
            tokenValueToRoman = null;
            tokenValue = null;

        }
       

        /// <summary>
        /// Assumption:New token would be only one in query.otherwise we have to use array of element and add their values before multiply
        /// Get value for new token in question
        /// </summary>
        /// <param name="query">Question to be answered</param>
        private void GetValueOfToken(string query)
        {
            string[] tokenValue = Utilities.SplitQueryBetweenTwoString(query, "is", "?");
            List<char> tokenValueToRoman = new List<char>();
            string element = null;
            for (int i = 0; i < tokenValue.Length; i++)
            {
                if (_queries.TokenMap.Keys.Contains(tokenValue[i]))
                {
                    tokenValueToRoman.Add(_queries.TokenMap[tokenValue[i]]);
                }
                else if (_queries.NewTokensValue.Keys.Contains(tokenValue[i]))
                {
                    element = tokenValue[i];
                }
                else
                {
                    throw new RomanNumeralsException("I have no idea what you are talking about");
                }
            }

            string valueUnit = query.Split(' ')[2];           
            float elementValue = EvaluateExpression(string.Join("", tokenValueToRoman.ToArray()), _queries.NewTokensValue[element]);
            Utilities.PrintOutput(string.Join(" ", tokenValue) + " is " + Math.Round(elementValue) + " " + valueUnit);
        }
        /// <summary>
        /// Evaluate Roman Expression and convert it into Decimal number.
        /// </summary>
        /// <param name="romanString">Roman Expression string</param>
        /// <param name="newTokenValue">Value of any new tokens</param>
        /// <returns>Decimal value of roman rxpression and token value</returns>
        private float EvaluateExpression(string romanString, float newTokenValue = 1)
        {            
            
            if (RomanNumber.IsValidRomanString(romanString))
            {
                IExpression romanExpression = new RomanNumber(romanString);
                return  romanExpression.Interpret() * newTokenValue;                
            }
            else
            {
                throw new RomanNumeralsException("Roman Expression is not Valid");
            }
        }
    }
}
