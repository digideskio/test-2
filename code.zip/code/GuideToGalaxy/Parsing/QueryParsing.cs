﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using GuideToGalaxy.Utility;

namespace GuideToGalaxy
{
    /// <summary>
    /// This class reads file and prepare question list with requried data.
    /// </summary>
    public class QueryParsing 
    {
        /// <summary>
        /// Map new token to Roman Numeral charcters.
        /// </summary>
        private Dictionary<string, char> _tokenToMap;

        /// <summary>
        /// New found tokens 
        /// </summary>
        private  Dictionary<string, float> _newTokensValue ;

        /// <summary>
        /// List of question to be answered
        /// </summary>
        private List<string> _questionsList ;
        
        /// <summary>
        /// Get the questions list
        /// </summary>        
        public List<string> QuestionsList
        {
            get { return _questionsList; }
        }
        
        /// <summary>
        /// Get mapped token.
        /// </summary>
        public Dictionary<string, char> TokenMap
        {
            get { return _tokenToMap; }
        }

        /// <summary>
        /// Get new token and their values.
        /// </summary>
        public Dictionary<string, float> NewTokensValue
        {
            get { return _newTokensValue; }
        }

        /// <summary>
        /// Constructor to initialize global variable
        /// </summary>
        public QueryParsing()
        {
            this._tokenToMap = new Dictionary<string, char>();
            this._newTokensValue = new Dictionary<string, float>();
            this._questionsList = new List<string>();
        }
               
        /// <summary>
        /// Read file line by line and prepare collection for answeres.
        /// </summary>
        /// <param name="fileName">File with list of questions.</param>
        public void ReadFile(string fileName)
        {
            const int bufferSize = 128;
            using (var fileStream = File.OpenRead(fileName))
            {
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, bufferSize))
                {
                    String line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        ParseQuestions(line);
                    }
                }
            }
        }

        /// <summary>
        /// Parse each line and found meaningfull information from it.
        /// </summary>
        /// <param name="line">Question with tokens</param>
        public void ParseQuestions(string line)
        {
            string[] tokens = line.Split(' ');

            if (line.EndsWith("?"))
            {
                _questionsList.Add(line);
            }
            else if (tokens.Length == 3 && tokens[1].Equals("is", StringComparison.CurrentCultureIgnoreCase))
            {
               this.TokenMap[tokens[0]] = Convert.ToChar(tokens[2].Trim());
            }
            //This if blocks is not necessary , but in case if some thing else
            else if (line.EndsWith("Credits"))
            {                
                FindNewTokenValues(line);
            }
        }

        /// <summary>
        /// Found new Tokens value
        /// </summary>
        /// <param name="line">Question with new tokens</param>
        public void FindNewTokenValues(string line)
        {
            string[] tokens = line.Split(' ');
            int credit = 0; string[] values = null; string newToken = string.Empty;
            for (int i = 0; i < tokens.Length; i++)
            {
                if (tokens[i].Equals("Credits", StringComparison.CurrentCultureIgnoreCase))
                {
                    credit = Convert.ToInt32(tokens[i - 1]);
                }
                if (tokens[i].Equals("is", StringComparison.CurrentCultureIgnoreCase))
                {
                    values = new string[i - 1]; newToken = tokens[i - 1];
                    Array.Copy(tokens, 0, values, 0, i - 1);
                }
            }
            StringBuilder combineExpression = new StringBuilder();
            foreach (string item in values)
            {
                combineExpression.Append(this.TokenMap[item]);
            }

            IExpression romanNumber = new RomanNumber(combineExpression.ToString());
            float tempExpressionValue = romanNumber.Interpret();//.ConvertRomanToDecimal(combineExpression.ToString());
            _newTokensValue.Add(newToken, (credit / tempExpressionValue));

            //object will available for garbage collector during mark phase
            //string can be huge so they can get allocated on heap.
            romanNumber = null; tokens = null;
        }        
    }
}
