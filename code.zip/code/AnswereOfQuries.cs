﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Exceptions;

namespace GuideToGalaxy
{
    class AnswereOfQueries : ParseQueries
    {
        public void ProcessQuestions()
        {
            foreach (string question in questionsList.Keys)
            {
                GetAnswere(question);
            }
        }

        private void GetAnswere(string question)
        {
            if (question.StartsWith("how much", StringComparison.CurrentCultureIgnoreCase))
            {
                GetValueForRoman(question);
            }
            else
            {
                GetValueOfToken(question);
            }
        }
        private void GetValueForRoman(string query)
        {

            if (IsVAlidQuery(query))
            {
                List<char> tokenValueToRoman = new List<char>();
                string[] tokenValue = SplitQuery(query);
                for (int i = 0; i < tokenValue.Length; i++)
                {
                    tokenValueToRoman.Add(tokenToMap[tokenValue[i]]);
                }
                int value = new RomanNumber().ConvertRomanToDecimal(string.Join("", tokenValueToRoman.ToArray()));
                //tokenValue.Add("is");
                //tokenValue.Add(value.ToString());
                Console.WriteLine(string.Join(" ",tokenValue) + " is "+ value);
            }
            else
            {
                throw new RomanNumeralsException("Roman Expression is not Valid");
            }
        }
        private void GetValueOfToken(string query)
        {
            if (IsVAlidQuery(query))
            {
                string[] tokenValue = SplitQuery(query);
                List<char> tokenValueToRoman = new List<char>();
                String element = null;
                for (int i = 0; i < tokenValue.Length; i++)
                {
                    if (tokenToMap.Keys.Contains(tokenValue[i]))
                    {
                        tokenValueToRoman.Add(tokenToMap[tokenValue[i]]);
                    }
                    else if (existingTokensValue.Keys.Contains(tokenValue[i]))
                    {
                        element = tokenValue[i];
                    }
                    else
                    {
                        throw new RomanNumeralsException(query + " : I have no idea what you are talking about");
                    }
                }
                float elementValue = (new RomanNumber().ConvertRomanToDecimal(string.Join("",tokenValueToRoman.ToArray())) * existingTokensValue[element]);
                //tokenValue.Add("is");
                // tokenValue.Add(elementValue.ToString());tokenValue.Add("Credits");
                Console.WriteLine(string.Join(" ", tokenValue) + " is " + elementValue + " Credits");
            }
            else
            {
                throw new RomanNumeralsException("Roman Expression is not Valid");
            }
        }

        private static String outputFormatter(string output)
        {
            return output.ToString().Replace(",", "").Replace("[", "").Replace("]", "");
        }

        private bool IsVAlidQuery(string query)
        {
            return true;
           /* System.Text.RegularExpressions.Regex rgExpression = new System.Text.RegularExpressions.Regex("[$&+,:;=@#|]");
            return rgExpression.Match(query).Success;*/
        }

        private static string[] SplitQuery(string query)
        {
            string[] queryArray = query.Split(' ');
            int startIndex = 0, endIndex = 0;
            for (int i = 0; i < queryArray.Length; i++)
            {
                if (queryArray[i].Equals("is", StringComparison.CurrentCultureIgnoreCase))
                {
                    startIndex = i + 1;
                }
                else if (queryArray[i].Equals("?", StringComparison.CurrentCultureIgnoreCase))
                {
                    endIndex = i;

                }
            }
            string[] temp = new string[queryArray.Length - startIndex - 1];
            Array.Copy(queryArray, startIndex, temp, 0, temp.Length);
            //temp.AddRange(queryArray);
            return temp;
        }
    }
}
