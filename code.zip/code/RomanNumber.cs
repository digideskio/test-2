﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Utility;
using GuideToGalaxy.Exceptions;

namespace GuideToGalaxy
{
    /// <summary>
    /// This class interpret langauge in Roman Numerals.
    /// </summary>
    public class RomanNumber : IExpression
    {
        /// <summary>
        /// String which contain Roman Numeral Expression
        /// </summary>
        private string _romanExpression;
        
        /// <summary>
        ///Initilaze Roman numers with Roman Numeral expression 
        /// </summary>
        /// <param name="romanExpression"></param>
        public RomanNumber(string romanExpression)
        {
            this._romanExpression = romanExpression;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        float IExpression.Interpret()
        {
            return this.ConvertRomanToDecimal(_romanExpression);
        }

        /// <summary>
        /// Covert Roamn Expression into Decimal
        /// </summary>
        /// <param name="romanValue">Roman Expression</param>
        /// <returns>Corresponding decimal (float is not necessary.)</returns>
        private float ConvertRomanToDecimal(string romanValue)
        {
            float result = 0;
            int lastNumber = 0;
            char[] romanCharcters = romanValue.ToUpper().ToCharArray();
            IExpression conversionRules ;
            for (int i = romanCharcters.Length - 1; i >= 0; i--)
            {                
                conversionRules = new ConversionRuleList(romanCharcters[i], lastNumber,result);
                result = conversionRules.Interpret();
                lastNumber = Constants.romanCharcterValues[romanCharcters[i]];
            }            
            return result;
        }
       
    }
}
