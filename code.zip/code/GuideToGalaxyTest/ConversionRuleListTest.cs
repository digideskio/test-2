﻿using GuideToGalaxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace GuideToGalaxyTest
{
    
    
    /// <summary>
    ///This is a test class for ConversionRuleListTest and is intended
    ///to contain all ConversionRuleListTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ConversionRuleListTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ConversionRuleList Constructor
        ///</summary>
        [TestMethod()]
        public void ConversionRuleListConstructorTest()
        {
            char currentChar = '\0'; 
            int previousValue = 0; 
            float result = 0F; 
            ConversionRuleList target = new ConversionRuleList(currentChar, previousValue, result);
            Assert.AreNotEqual(target, null);
        }

        /// <summary>
        ///A test for ConversionRuleList Constructor
        ///</summary>
        [TestMethod()]
        public void ConversionRuleListConstructorTest1()
        {
            ConversionRuleList target = new ConversionRuleList();
            Assert.AreNotEqual(target, null);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for Interpret
        ///</summary>
        [TestMethod()]
        public void InterpretTest()
        {

            ConversionRuleList target = new ConversionRuleList('I',1,0); 
            float expected = 1F; 
            float actual;
            actual = target.Interpret();
            Assert.AreEqual(expected, actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Substract
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        public void SubstractTest()
        {
            ConversionRuleList_Accessor target = new ConversionRuleList_Accessor(); 
            int current = 0; 
            int previous = 0; 
            float result = 0F; 
            float expected = 0F; 
            float actual;
            actual = target.Substract(current, previous, result);
            Assert.AreEqual(expected, actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CurrentCharcter
        ///</summary>
        [TestMethod()]
        public void CurrentCharcterTest()
        {
            ConversionRuleList target = new ConversionRuleList();             
            char actual;
            actual = target.CurrentCharacter;
            Assert.AreEqual('\0',actual);
        }

        /// <summary>
        ///A test for PreviousValue
        ///</summary>
        [TestMethod()]
        public void PreviousValueTest()
        {
            ConversionRuleList target = new ConversionRuleList(); 
            int actual;
            actual = target.PreviousValue;
            Assert.AreEqual(0, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Result
        ///</summary>
        [TestMethod()]
        public void ResultTest()
        {
            ConversionRuleList target = new ConversionRuleList(); 
            float actual;
            actual = target.Result;
            Assert.AreEqual(0, actual);
        }
    }
}
