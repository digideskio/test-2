﻿using GuideToGalaxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace GuideToGalaxyTest
{


    /// <summary>
    ///This is a test class for CommnucationInterfaceTest and is intended
    ///to contain all CommnucationInterfaceTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CommnucationInterfaceTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for CommnucationInterface Constructor
        ///</summary>
        [TestMethod()]
        public void CommnucationInterfaceConstructorTest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            Assert.AreNotEqual(null, target);
            Assert.AreEqual(null, target._queries);

            QueryParsing queryParsing = new QueryParsing();
            target = new CommnucationInterface_Accessor(queryParsing);
            Assert.AreNotEqual(null, target);
            Assert.AreNotEqual(null, target._queries);
            // Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for CommnucationInterface Constructor with Dependency injection
        ///</summary>
        [TestMethod()]
        public void CommnucationInterfaceConstructorWithDITest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            Assert.AreNotEqual(null, target);
            Assert.AreEqual(null, target._queries);

            QueryParsing queryParsing = new QueryParsing();
            target = new CommnucationInterface_Accessor(queryParsing);
            Assert.AreNotEqual(null, target);
            Assert.AreNotEqual(null, target._queries);
            // Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for GetAnswere
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException")]
        public void GetAnswereTest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            string question = string.Empty;
            target.GetAnswere(question);
            //Assert.AreNotEqual(null, target);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for GetValueForRoman
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException")]
        public void GetValueForRomanTest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            string query = string.Empty;
            target.GetValueForRoman(query);
            // Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for GetValueOfToken
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException")]
        public void GetValueOfTokenTest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            string query = string.Empty;
            target.GetValueOfToken(query);
            // Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for ProcessQuestions
        ///</summary>
        [TestMethod()]       
        public void ProcessQuestionsTest()
        {
            QueryParsing_Accessor queryParsing = new QueryParsing_Accessor();
            queryParsing._questionsList.Add("how much is pish tegj glob glob ?");
            queryParsing._tokenToMap.Add("pish",'X');
            queryParsing._tokenToMap.Add("tegj", 'L');
            queryParsing._tokenToMap.Add("glob", 'I');
            CommnucationInterface target = new CommnucationInterface((QueryParsing)queryParsing.Target);
            target.ProcessQuestions();
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for EvaluateExpressionTest
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "Method can throw RomanNumerals format Exception")]
        public void EvaluateExpressionTest()
        {
            CommnucationInterface_Accessor target = new CommnucationInterface_Accessor();
            string romanString = string.Empty;
            float result = target.EvaluateExpression(romanString);
            Assert.AreEqual(result, 0L);

            float newTokenValue = 45;
            romanString = "XLV";
            result = target.EvaluateExpression(romanString, newTokenValue);
            Assert.AreEqual(result, 2025L);

            romanString = "XLCCV";
            result = target.EvaluateExpression(romanString, newTokenValue);
            Assert.AreEqual(result, 0);

        }
    }
}
