﻿using GuideToGalaxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace GuideToGalaxyTest
{
    
    
    /// <summary>
    ///This is a test class for QueryParsingTest and is intended
    ///to contain all QueryParsingTest Unit Tests
    ///</summary>
    [TestClass()]
    public class QueryParsingTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for QueryParsing Constructor
        ///</summary>
        [TestMethod()]
        public void ParseQueriesConstructorTest()
        {
            QueryParsing target = new QueryParsing();
            Assert.AreNotEqual(target, null);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for FindNewTokenValues
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(System.NullReferenceException), "This method can throw NullReferenceException in case of null or empty line.")]
        public void FindNewTokenValuesEmptyTest()
        {
            QueryParsing target = new QueryParsing(); 
            string line = string.Empty; 
            target.FindNewTokenValues(line);
            Assert.AreEqual(target, null);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for FindNewTokenValues
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can throw RomanNumeralsException")]
        public void FindNewTokenValuesNonEmptyTest()
        {
            QueryParsing_Accessor target = new QueryParsing_Accessor();
            target.TokenMap["glob"] = 'I';
            string line = "glob glob Silver is 34 Credits";
            target.FindNewTokenValues(line);
            Assert.AreEqual(target.NewTokensValue["Silver"], 17.0);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for QueryParsing
        ///</summary>
        [TestMethod()]        
        public void ParseQuestionsTest()
        {
            QueryParsing target = new QueryParsing(); 
            string line = string.Empty; 
            target.ParseQuestions(line);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }     

        /// <summary>
        ///A test for ReadFile
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(System.ArgumentException), "This method can be throw ArgumentException in case of null or empty file path")]
        public void ReadFileWithEmptyFileNameTest()
        {
            QueryParsing target = new QueryParsing(); 
            string fileName = string.Empty; 
            target.ReadFile(fileName);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for ReadFile
        ///</summary>
        [TestMethod()]
        //[ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException")]
        public void ReadFileWithFileNameTest()
        {
            QueryParsing target = new QueryParsing();
            string fileName = UtilitiesTest.GetRelativePath(AppDomain.CurrentDomain.BaseDirectory, "input.txt");
            target.ReadFile(fileName);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }


        /// <summary>
        ///A test for NewTokensValue
        ///</summary>
        [TestMethod()]
        public void NewTokensValueTest()
        {
            QueryParsing target = new QueryParsing(); 
            Dictionary<string, float> actual;
            actual = target.NewTokensValue;
            Assert.AreEqual(0, target.NewTokensValue.Keys.Count);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for QuestionsList
        ///</summary>
        [TestMethod()]
        public void QuestionsListTest()
        {
            QueryParsing target = new QueryParsing(); 
            List<string> actual;
            actual = target.QuestionsList;
            Assert.AreEqual(0, target.QuestionsList.Count);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for TokenMap
        ///</summary>
        [TestMethod()]
        public void TokenMapTest()
        {
            QueryParsing target = new QueryParsing(); 
            Dictionary<string, char> actual;
            actual = target.TokenMap;
            Assert.AreEqual(0, target.NewTokensValue.Keys.Count);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
