﻿using GuideToGalaxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace GuideToGalaxyTest
{
    
    
    /// <summary>
    ///This is a test class for RomanNumberTest and is intended
    ///to contain all RomanNumberTest Unit Tests
    ///</summary>
    [TestClass()]
    public class RomanNumberTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for RomanNumber Constructor
        ///</summary>
        [TestMethod()]
        public void RomanNumberConstructorTest()
        {
            string romanExpression = string.Empty; 
            RomanNumber target = new RomanNumber(romanExpression);
            Assert.AreNotEqual(target, null);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for ConvertRomanToDecimal
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        public void ConvertRomanToDecimalTest()
        {
            string romanExpression = "CD"; 
            RomanNumber_Accessor target = new RomanNumber_Accessor(romanExpression);            
            float expected = 400F; 
            float actual;
            actual = target.ConvertRomanToDecimal(romanExpression);
            Assert.AreEqual(expected, actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for IsValidRomanString
        ///</summary>
        [TestMethod()]
        public void IsValidRomanStringTest()
        {
            string romanString = string.Empty;
            bool expected = true;
            bool actual;
            actual = RomanNumber.IsValidRomanString(romanString);
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for IsValidRomanString
        ///</summary>
        [TestMethod()]
        public void IsValidRomanStringAutomateTest()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            using (FileStream fs = File.Open(UtilitiesTest.GetRelativePath(baseDir, "ValidRomanNumerals.txt", "Resources"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] numbers = line.Split('\t');
                    string romanString = numbers[0];
                    bool expected = Convert.ToBoolean(numbers[1]);
                    bool actual;
                    actual = RomanNumber.IsValidRomanString(romanString);
                    Assert.AreEqual(expected, actual);
                }
            }
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GuideToGalaxy.IExpression.Interpret
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        //[ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException))]
        public void InterpretTest()
        {
            string romanExpression = "XI"; 
            IExpression target = new RomanNumber(romanExpression); 
            float expected = 11F; 
            float actual;
            actual = target.Interpret();
            Assert.AreEqual(expected, actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///Test Roman Numeral class by reading and verifing files entries
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
       // [DeploymentItem("RomanNumbers.txt", @"D:\OLD\program\GuideToGalaxyTest\Resources")]        
        public void InterpretAutomateTest()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            using (FileStream fs = File.Open(UtilitiesTest.GetRelativePath(baseDir, "RomanNumbers.txt", "Resources") , FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] numbers = line.Split('=');
                    string romanExpression = numbers[1]; 
                    IExpression target = new RomanNumber(romanExpression); 
                    float expected = System.Convert.ToInt64(numbers[0]); 
                    float actual;
                    actual = target.Interpret();
                    Assert.IsTrue(expected == actual, "Test case failed for Roman Numeral: "+romanExpression+" expected output is "+expected+" but actual output is "+actual);
                    Assert.AreEqual(expected, actual);
                }
            }           
        }


        /// <summary>
        ///Test Roman Numeral class by reading and verifing files entries
        ///</summary>
        [TestMethod()]
        [DeploymentItem("GuideToGalaxy.exe")]
        // [DeploymentItem("RomanNumbers.txt", @"D:\OLD\program\GuideToGalaxyTest\Resources")]
        [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException in case of wrong or incorrect Roman Numeral Expression")]
        public void ConvertRomanToDecimalAutomateTest()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            using (FileStream fs = File.Open(UtilitiesTest.GetRelativePath(baseDir, "RomanNumbers.txt", "Resources"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] numbers = line.Split('=');
                    string romanExpression = numbers[1]; 
                    RomanNumber_Accessor target = new RomanNumber_Accessor(romanExpression);
                    float expected = System.Convert.ToInt64(numbers[0]); 
                    float actual;
                    actual = target.ConvertRomanToDecimal(romanExpression);                   
                    Assert.IsTrue(expected == actual, "Test case failed for Roman Numeral: " + romanExpression + " expected output is " + expected + " but actual output is " + actual);
                    Assert.AreEqual(expected, actual);
                }
            }
        }
    }
}
