﻿using GuideToGalaxy.Exceptions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace GuideToGalaxyTest
{
    
    
    /// <summary>
    ///This is a test class for RomanNumeralsExceptionTest and is intended
    ///to contain all RomanNumeralsExceptionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class RomanNumeralsExceptionTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for RomanNumeralsException Constructor
        ///</summary>
        [TestMethod()]
        public void RomanNumeralsExceptionConstructorTest()
        {
            string message = string.Empty; 
            Exception innerException = null; 
            RomanNumeralsException target = new RomanNumeralsException(message, innerException);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }             
             

        /// <summary>
        ///A test for RomanNumeralsException Constructor
        ///</summary>
        [TestMethod()]
        public void RomanNumeralsExceptionConstructorTest3()
        {
            RomanNumeralsException target = new RomanNumeralsException();
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for RomanNumeralsException Constructor
        ///</summary>
        [TestMethod()]
        public void RomanNumeralsExceptionConstructorTest4()
        {
            string message = string.Empty; 
            RomanNumeralsException target = new RomanNumeralsException(message);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
