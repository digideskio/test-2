﻿using GuideToGalaxy.Utility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace GuideToGalaxyTest
{
    
    
    /// <summary>
    ///This is a test class for UtilitiesTest and is intended
    ///to contain all UtilitiesTest Unit Tests
    ///</summary>
    [TestClass()]
    public class UtilitiesTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


      


        /// <summary>
        ///A test for PrintOutput
        ///</summary>
        [TestMethod()]
        public void PrintOutputTest()
        {
            string message = string.Empty; 
            Utilities.PrintOutput(message);
            //Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for SplitQueryBetweenTwoString
        ///</summary>
        [TestMethod()]
       // [ExpectedException(typeof(GuideToGalaxy.Exceptions.RomanNumeralsException), "This method can be throw RomanNumeralsException")]
        [ExpectedException(typeof(System.OverflowException), "Index out of bound in case of emty of null strings")]
        public void SplitQueryBetweenTwoStringTest()
        {           
            string query = string.Empty; 
            string startString = string.Empty; 
            string endString = string.Empty; 
            string[] expected = null; 
            string[] actual;
            actual = Utilities.SplitQueryBetweenTwoString(query, startString, endString);
            Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///  Get The resources's file relative path.
        /// </summary>
        /// <param name="baseDire">Base directroy of current Project</param>
        /// <param name="fileName">File name whose relative path needed. </param>
        /// <param name="folderName">Folder in which file exist. </param>
        /// <returns></returns>
        public static string GetRelativePath(string baseDire, string fileName, string folderName = "Resources")
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            return baseDir.Substring(0, baseDir.IndexOf("bin") - 1) + @"\" + folderName + @"\" + fileName;
        }
    }
}
