﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Exceptions;

namespace GuideToGalaxy
{
    /// <summary>
    /// Main class to start application.
    /// </summary>
    class Program
    {
        /// <summary>
        /// User need to provide file path as Command-Line argument
        /// </summary>
        /// <param name="args">Comman</param>
        static void Main(string[] args)
        {
            string filePath = null;
            if (args.Length != 0)
            {
                filePath = args[0];
            }
            else 
            {   
                //Default Path, if user not specify any thing.
                filePath = @"G:\projects\GuideToGalaxy\bin\Debug\input.txt"; 
            }
            try
            {                
                AnswereQueries answere = new AnswereQueries();
                if (System.IO.File.Exists(filePath))
                {
                    answere.ReadFile(filePath);
                    answere.ProcessQuestions();
                }
                else { Console.WriteLine("File not Found! Pls check file path."); }
                                
            }            
            catch (RomanNumeralsException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
