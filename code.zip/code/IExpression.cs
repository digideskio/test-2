﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuideToGalaxy
{
    /// <summary>
    /// Interface for Interpret pattern.
    /// </summary>
    public interface IExpression
    {
        float Interpret();
    }
}
