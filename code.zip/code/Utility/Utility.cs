﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuideToGalaxy.Utility
{
    /// <summary>
    /// This class provde common utility methods to application.
    /// </summary>
    public static class Utilities
    {
        /// <summary>
        /// Split Query string between two specific string
        /// </summary>
        /// <param name="query">Query string to be split</param>
        /// <param name="startString">Start split string</param>
        /// <param name="endString">End split string</param>
        /// <returns>Array of splited values.</returns>
        public static string[] SplitQueryBetweenTwoString(string query, string startString, string endString)
        {
            string[] queryArray = query.Split(' ');
            int startIndex = -1, endIndex = 0;
            for (int i = 0; i < queryArray.Length; i++)
            {
                if (queryArray[i].Equals(startString, StringComparison.CurrentCultureIgnoreCase))
                {
                    startIndex = i + 1;
                }
                else if (queryArray[i].Equals(endString, StringComparison.CurrentCultureIgnoreCase))
                {
                    endIndex = i;

                }
            }
            if (startIndex == -1) 
            {
                throw new GuideToGalaxy.Exceptions.RomanNumeralsException ("I have no idea what you are talking about"); 
            }
            string[]  splitedString = new string[queryArray.Length - startIndex - 1];
            Array.Copy(queryArray, startIndex, splitedString, 0, splitedString.Length);            
            return splitedString;
        }

        /// <summary>
        /// Print out put message to Console.
        /// Assumption: Rounded off values of Queries.
        /// </summary>
        /// <param name="message">Message to be print on console.</param>
        public static void PrintOutput(string message)
        {
            Console.WriteLine(message);
        }

        /// <summary>
        /// Checks strings for a vlid Roman Numeral
        /// </summary>
        /// <param name="romanString">Roman Numeral string.</param>
        /// <returns>String is valid Roman Numeral or not</returns>
        public static bool IsValidRomanString(string romanString)
        {            
            System.Text.RegularExpressions.Regex rgExpression = new System.Text.RegularExpressions.Regex("^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return rgExpression.Match(romanString).Success;
        }
    }
}
