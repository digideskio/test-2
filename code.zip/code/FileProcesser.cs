﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using GuideToGalaxy.Utility;

namespace GuideToGalaxy
{
    public class ParseQueries
    {
        public static Dictionary<string, char> tokenToMap = new Dictionary<string, char>();

        public static Dictionary<string, string> questionsList = new Dictionary<string, string>();

        public static Dictionary<string, float> existingTokensValue = new Dictionary<string, float>();

        public static List<string> newTokensValues = new List<string>();

        public void ReadFile(string fileName)
        {

            const Int32 BufferSize = 128;
            using (var fileStream = File.OpenRead(fileName))
            {
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize))
                {
                    String line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        ParseLine(line);
                    }
                }
            }
        }

        public void ParseLine(string line)
        {
            string[] str = line.Split(' ');

            if (line.EndsWith("?"))
            {
                questionsList.Add(line, string.Empty);
            }
            else if (str.Length == 3 && str[1].Equals("is", StringComparison.CurrentCultureIgnoreCase))
            {
                tokenToMap[str[0]] = Convert.ToChar(str[2].Trim());
            }
            //This if blocks is not necessary , but in case if some thing else
            else if (line.EndsWith("Credits"))
            {
                newTokensValues.Add(line);
                FindNewTokenValues(line);
            }
        }

        public void FindNewTokenValues(string line)
        {
            string[] tokens = line.Split(' ');
            int credit = 0; string[] values = null; string newToken = string.Empty;
            for (int i = 0; i < tokens.Length; i++)
            {
                if (tokens[i].Equals("Credits", StringComparison.CurrentCultureIgnoreCase))
                {
                    credit = Convert.ToInt32(tokens[i - 1]);
                }
                if (tokens[i].Equals("is", StringComparison.CurrentCultureIgnoreCase))
                {
                    values = new string[i - 1]; newToken = tokens[i - 1];
                    Array.Copy(tokens, 0, values, 0, i - 1);
                }
            }
            StringBuilder combineExpression = new StringBuilder();
            foreach (string item in values)
            {
                combineExpression.Append(tokenToMap[item]);
            }
            RomanNumber romanNumber = new RomanNumber();
            float tempExpressionValue = romanNumber.ConvertRomanToDecimal(combineExpression.ToString());
            existingTokensValue.Add(newToken, (credit / tempExpressionValue));

        }
    }
}
