﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GuideToGalaxy.Exceptions;
using GuideToGalaxy.Utility;

namespace GuideToGalaxy
{
    /// <summary>
    /// This class answere every query by user (Merchant)
    /// </summary>
    class AnswereQueries : ParseQueries
    {
        /*private IExpression _romanNumber;
        private IExpression _parseQueries;
        public AnswereQueries(IExpression romanExpression, IExpression parseQueries)
        {
            this._romanNumber = romanExpression;
            this._parseQueries = parseQueries;
        }*/

        public AnswereQueries()
        { 

        }       

        /// <summary>
        /// Itrate each question and try to find out answere.
        /// </summary>
        public void ProcessQuestions()
        {
            foreach (string question in this.QuestionsList)
            {
                GetAnswere(question);
            }
        }

        /// <summary>
        /// Classify answere depending on  
        /// </summary>
        /// <param name="question">Question to be answered</param>
        private void GetAnswere(string question)
        {
            if (question.StartsWith("how much", StringComparison.CurrentCultureIgnoreCase))
            {
                GetValueForRoman(question);
            }
            else
            {
                GetValueOfToken(question);
            }
        }

        /// <summary>
        ///Get value of Roman Numeral charcters 
        /// </summary>
        /// <param name="query">Question to be answered</param>
        private void GetValueForRoman(string query)
        {
            List<char> tokenValueToRoman = new List<char>();
            string[] tokenValue = Utilities.SplitQueryBetweenTwoString(query, "is", "?");
            for (int i = 0; i < tokenValue.Length; i++)
            {
                tokenValueToRoman.Add(TokenMap[tokenValue[i]]);
            }

            string romanString = string.Join("", tokenValueToRoman.ToArray());
            if (Utilities.IsValidRomanString(romanString))
            {
                IExpression romanExpression = new RomanNumber(romanString);
                float value = romanExpression.Interpret();//new RomanNumber().ConvertRomanToDecimal(string.Join("", tokenValueToRoman.ToArray()));
                Utilities.PrintOutput(string.Join(" ", tokenValue) + " is " + Math.Round(value));
            }
            else
            {
                throw new RomanNumeralsException("Roman Expression is not Valid");
            }

        }

        /// <summary>
        /// Assumption:New token would be only one in query.otherwise we have to use array of element and add their values before multiply
        /// Get value for new token in question
        /// </summary>
        /// <param name="query">Question to be answered</param>
        private void GetValueOfToken(string query)
        {
            string[] tokenValue = Utilities.SplitQueryBetweenTwoString(query, "is", "?");
            List<char> tokenValueToRoman = new List<char>();
            string element = null;
            for (int i = 0; i < tokenValue.Length; i++)
            {
                if (TokenMap.Keys.Contains(tokenValue[i]))
                {
                    tokenValueToRoman.Add(TokenMap[tokenValue[i]]);
                }
                else if (NewTokensValue.Keys.Contains(tokenValue[i]))
                {
                    element = tokenValue[i];
                }
                else
                {
                    throw new RomanNumeralsException("I have no idea what you are talking about");
                }
            }

            string romanString = string.Join("", tokenValueToRoman.ToArray());
            if (Utilities.IsValidRomanString(romanString))
            {
                IExpression romanExpression = new RomanNumber(romanString);
                float elementValue = romanExpression.Interpret() * NewTokensValue[element];
                Utilities.PrintOutput(string.Join(" ", tokenValue) + " is " + Math.Round(elementValue) + " Credits");
            }
            else
            {
                throw new RomanNumeralsException("Roman Expression is not Valid");
            }

        }
    }
}
